import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import type { FileFilterCallback } from "multer";
import * as path from "path";
import * as fs from "fs";
import sharp from "sharp";
import { v4 as uuidv4 } from "uuid";
import { MAX_FILE_SIZE, ALLOWED_FILE_TYPES } from "@shared/schema";
import archiver from "archiver";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure multer for file uploads
  const upload = multer({
    storage: multer.diskStorage({
      destination: (_req: Request, _file: Express.Multer.File, cb) => {
        cb(null, storage.getUploadPath(''));
      },
      filename: (_req: Request, file: Express.Multer.File, cb) => {
        const uniqueFilename = `${uuidv4()}${path.extname(file.originalname)}`;
        cb(null, uniqueFilename);
      }
    }),
    limits: {
      fileSize: MAX_FILE_SIZE // 10MB
    },
    fileFilter: (_req: Request, file: Express.Multer.File, cb: FileFilterCallback) => {
      if (ALLOWED_FILE_TYPES.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error(`Only ${ALLOWED_FILE_TYPES.join(', ')} files are allowed!`));
      }
    }
  });

  // Serve uploaded files
  app.use('/api/uploads', express.static(storage.getUploadPath('')));

  // Image upload endpoint
  app.post('/api/upload', upload.single('file'), async (req: Request & { file?: Express.Multer.File }, res: Response) => {
    try {
      console.log('Upload request received:', req.body);
      console.log('Files on request:', req.file);
      
      if (!req.file) {
        console.log('No file in the request');
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const file = req.file;
      
      // Create image record
      const image = await storage.createImage({
        originalName: file.originalname,
        originalPath: `/api/uploads/${file.filename}`,
        enhancedPath: null,
        mimeType: file.mimetype,
        size: file.size,
        status: 'processing',
        userId: null,
        createdAt: new Date().toISOString()
      });

      // Return the image ID for the client to poll status
      res.status(201).json({ 
        id: image.id,
        originalPath: image.originalPath
      });

      // Process the image asynchronously
      processImage(image.id, file.path)
        .catch(err => console.error('Error processing image:', err));
      
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ message: 'Error uploading file' });
    }
  });

  // Get image status
  app.get('/api/images/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      const image = await storage.getImage(id);
      
      if (!image) {
        return res.status(404).json({ message: 'Image not found' });
      }
      
      res.json(image);
    } catch (error) {
      console.error('Error getting image:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Get sample images for the gallery
  app.get('/api/samples', (_req: Request, res: Response) => {
    // This endpoint returns sample high-quality images for the gallery
    const samples = [
      {
        id: 1,
        title: 'Landscape Enhancement',
        description: 'Improved clarity, vibrant colors, and enhanced details',
        original: 'https://images.unsplash.com/photo-1516298773066-c48f8e9bd92b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=70',
        enhanced: 'https://images.unsplash.com/photo-1516298773066-c48f8e9bd92b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=100'
      },
      {
        id: 2,
        title: 'Portrait Enhancement',
        description: 'Natural skin tones, sharpened details, and improved lighting',
        original: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=70',
        enhanced: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=100'
      },
      {
        id: 3,
        title: 'Architectural Enhancement',
        description: 'Improved structural details, perspective correction, and contrast',
        original: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=70',
        enhanced: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=100'
      },
      {
        id: 4,
        title: 'Macro Photography Enhancement',
        description: 'Ultra-sharp textures, rich details, and optimized focus',
        original: 'https://images.unsplash.com/photo-1606041008023-472dfb5e530f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=70',
        enhanced: 'https://images.unsplash.com/photo-1606041008023-472dfb5e530f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=100'
      },
      {
        id: 5,
        title: 'Nature Close-up',
        description: 'Enhanced natural details and color vibrance',
        original: 'https://images.unsplash.com/photo-1579762593175-20226054cad0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=70',
        enhanced: 'https://images.unsplash.com/photo-1579762593175-20226054cad0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=100'
      },
      {
        id: 6,
        title: 'Urban Photography',
        description: 'Improved clarity and enhanced urban details',
        original: 'https://images.unsplash.com/photo-1573108724029-4c46571d6490?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=70',
        enhanced: 'https://images.unsplash.com/photo-1573108724029-4c46571d6490?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=100'
      }
    ];
    
    res.json(samples);
  });
  
  // Download code as a zip file
  app.get('/api/download-code', (_req: Request, res: Response) => {
    try {
      const projectRoot = process.cwd();
      
      // Create a file to stream archive data to
      res.attachment('pixelperfect.zip');
      
      const archive = archiver('zip', {
        zlib: { level: 9 } // Maximum compression
      });
      
      // Handle errors
      archive.on('error', (err) => {
        console.error('Archive error:', err);
        res.status(500).send('Error creating zip file');
      });
      
      // Pipe archive data to the response
      archive.pipe(res);
      
      // Add specific directories and files to the archive
      
      // Client directory
      archive.directory(path.join(projectRoot, 'client/src'), 'client/src');
      
      // Server directory
      archive.directory(path.join(projectRoot, 'server'), 'server');
      
      // Shared directory
      archive.directory(path.join(projectRoot, 'shared'), 'shared');
      
      // Add important root files
      const rootFiles = [
        'package.json',
        'tsconfig.json',
        'vite.config.ts',
        'tailwind.config.ts',
        'postcss.config.js',
        'drizzle.config.ts',
        'components.json'
      ];
      
      rootFiles.forEach(file => {
        const filePath = path.join(projectRoot, file);
        if (fs.existsSync(filePath)) {
          archive.file(filePath, { name: file });
        }
      });
      
      // Finalize the archive
      archive.finalize();
      
      console.log('Zip download started');
      
    } catch (error) {
      console.error('Download error:', error);
      res.status(500).send('Error creating zip file');
    }
  });

  // Helper function to process and enhance images
  async function processImage(imageId: number, filePath: string): Promise<void> {
    try {
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const image = await storage.getImage(imageId);
      if (!image) throw new Error('Image not found');
      
      // Update status to 'processing' (redundant but good practice)
      await storage.updateImage(imageId, { status: 'processing' });
      
      // Generate enhanced filename
      const parsedPath = path.parse(filePath);
      const enhancedFilename = `enhanced-${path.basename(parsedPath.name)}${parsedPath.ext}`;
      const enhancedPath = path.join(storage.getUploadPath(''), enhancedFilename);
      
      // Perform image enhancement with sharp
      await sharp(filePath)
        .modulate({ brightness: 1.1, saturation: 1.2 })
        .sharpen({ sigma: 1.2 })
        .normalise() // Normalize contrast
        .gamma(1.1) // Adjust gamma for better details
        .toFile(enhancedPath);
      
      // Update image record with enhanced path and status
      await storage.updateImage(imageId, {
        enhancedPath: `/api/uploads/${enhancedFilename}`,
        status: 'completed'
      });
      
    } catch (error) {
      console.error('Error processing image:', error);
      
      // Update image record with error status
      await storage.updateImage(imageId, { status: 'error' });
    }
  }

  const httpServer = createServer(app);
  return httpServer;
}

// Needed for the multer import and usage
import express from 'express';
