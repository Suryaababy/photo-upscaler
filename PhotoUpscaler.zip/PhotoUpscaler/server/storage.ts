import { images, type Image, type InsertImage, users, User, InsertUser } from "@shared/schema";
import { randomUUID } from "crypto";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { db } from "./db";
import { eq } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createImage(image: InsertImage): Promise<Image>;
  getImage(id: number): Promise<Image | undefined>;
  updateImage(id: number, update: Partial<InsertImage>): Promise<Image | undefined>;
  getAllImages(): Promise<Image[]>;
  
  createTempDirectory(): Promise<string>;
  getUploadPath(filename: string): string;
}

export class DatabaseStorage implements IStorage {
  private tempDir: string;
  private uploadsDir: string;

  constructor() {
    // Create a unique temporary directory for this session
    this.tempDir = path.join(os.tmpdir(), `pixelperfect-${randomUUID()}`);
    this.uploadsDir = path.join(this.tempDir, 'uploads');
    
    // Ensure directories exist
    fs.mkdirSync(this.tempDir, { recursive: true });
    fs.mkdirSync(this.uploadsDir, { recursive: true });
    
    // Log the directories for debugging
    console.log(`Temp dir: ${this.tempDir}`);
    console.log(`Uploads dir: ${this.uploadsDir}`);
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async createImage(insertImage: InsertImage): Promise<Image> {
    const [image] = await db
      .insert(images)
      .values(insertImage)
      .returning();
    return image;
  }
  
  async getImage(id: number): Promise<Image | undefined> {
    const [image] = await db.select().from(images).where(eq(images.id, id));
    return image || undefined;
  }
  
  async updateImage(id: number, update: Partial<InsertImage>): Promise<Image | undefined> {
    const [updatedImage] = await db
      .update(images)
      .set(update)
      .where(eq(images.id, id))
      .returning();
    return updatedImage || undefined;
  }
  
  async getAllImages(): Promise<Image[]> {
    return await db.select().from(images);
  }
  
  async createTempDirectory(): Promise<string> {
    const tempSubDir = path.join(this.tempDir, randomUUID());
    fs.mkdirSync(tempSubDir, { recursive: true });
    return tempSubDir;
  }
  
  getUploadPath(filename: string): string {
    return path.join(this.uploadsDir, filename);
  }
}

export const storage = new DatabaseStorage();
