import { useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Lightbulb, Clock, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ComparisonSlider from '@/components/ComparisonSlider';
import FileUploader from '@/components/FileUploader';
import FeatureCard from '@/components/FeatureCard';
import BeforeAfterExample from '@/components/BeforeAfterExample';
import ProcessingView from '@/components/ProcessingView';
import ResultView from '@/components/ResultView';

type ViewState = 'upload' | 'processing' | 'result';

interface UploadData {
  id: number;
  originalPath: string;
}

const Home = () => {
  const [viewState, setViewState] = useState<ViewState>('upload');
  const [uploadData, setUploadData] = useState<UploadData | null>(null);
  const [enhancedImagePath, setEnhancedImagePath] = useState<string>('');
  const { toast } = useToast();
  
  // Fetch sample images for the gallery
  const { data: sampleImages } = useQuery({
    queryKey: ['/api/samples'],
    staleTime: Infinity,
  });
  
  const handleFileUploadStart = useCallback(() => {
    // Reset any previous state
    setUploadData(null);
    setEnhancedImagePath('');
  }, []);
  
  const handleFileUploadSuccess = useCallback((data: UploadData) => {
    setUploadData(data);
    setViewState('processing');
  }, []);
  
  const handleFileUploadError = useCallback((error: string) => {
    toast({
      title: "Upload Error",
      description: error,
      variant: "destructive"
    });
  }, [toast]);
  
  const handleProcessingComplete = useCallback((enhancedPath: string) => {
    setEnhancedImagePath(enhancedPath);
    setViewState('result');
  }, []);
  
  const handleProcessingError = useCallback((message: string) => {
    toast({
      title: "Processing Error",
      description: message,
      variant: "destructive"
    });
    // Go back to upload state
    setViewState('upload');
  }, [toast]);
  
  const handleReset = useCallback(() => {
    setViewState('upload');
    setUploadData(null);
    setEnhancedImagePath('');
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-50 py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0 md:pr-8">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Transform Your Photos with <span className="text-primary">AI Enhancement</span>
              </h1>
              <p className="text-lg text-gray-600 mb-8">
                Our AI-powered technology turns your ordinary photos into stunning, high-quality images. Enhance resolution, fix imperfections, and breathe new life into your memories.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Button size="lg" className="text-lg">
                  Enhance Photos Now
                </Button>
                <Button variant="outline" size="lg" className="text-lg">
                  See Examples
                </Button>
              </div>
            </div>
            <div className="md:w-1/2">
              <ComparisonSlider
                beforeImage="https://images.unsplash.com/photo-1683009427513-28e163402d16?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=70"
                afterImage="https://images.unsplash.com/photo-1683009427513-28e163402d16?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=100"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section id="how-it-works" className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose PixelPerfect?</h2>
            <p className="mt-4 text-xl text-gray-600">Advanced AI technology that enhances your photos like magic</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard
              icon={Lightbulb}
              title="AI-Powered Enhancement"
              description="Our advanced algorithms analyze and enhance your photos automatically, increasing resolution and improving quality."
            />
            <FeatureCard
              icon={Clock}
              title="Lightning Fast"
              description="Experience rapid processing times with our optimized backend. Get enhanced photos in seconds, not minutes."
            />
            <FeatureCard
              icon={Layers}
              title="Multiple Enhancement Options"
              description="Choose from various enhancement modes to get the perfect look for every photo, from natural to dramatic."
            />
          </div>
        </div>
      </section>
      
      {/* Upload Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900">Enhance Your Photos Now</h2>
              <p className="mt-4 text-xl text-gray-600">Simply upload your image and let our AI do the magic</p>
            </div>
            
            <Card className="mb-8">
              <CardContent className="p-8">
                {viewState === 'upload' && (
                  <FileUploader 
                    onFileUploadStart={handleFileUploadStart}
                    onFileUploadSuccess={handleFileUploadSuccess}
                    onFileUploadError={handleFileUploadError}
                  />
                )}
                
                {viewState === 'processing' && uploadData && (
                  <ProcessingView 
                    imageId={uploadData.id}
                    onProcessingComplete={handleProcessingComplete}
                    onProcessingError={handleProcessingError}
                  />
                )}
                
                {viewState === 'result' && uploadData && enhancedImagePath && (
                  <ResultView 
                    originalImageUrl={uploadData.originalPath}
                    enhancedImageUrl={enhancedImagePath}
                    onDownload={() => {
                      toast({
                        title: "Download Started",
                        description: "Your enhanced image is being downloaded."
                      });
                    }}
                    onReset={handleReset}
                  />
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Gallery Section */}
      <section id="examples" className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Before & After Examples</h2>
            <p className="mt-4 text-xl text-gray-600">See the remarkable difference our AI enhancement makes</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {sampleImages ? (
              sampleImages.slice(0, 4).map((sample: any) => (
                <BeforeAfterExample
                  key={sample.id}
                  title={sample.title}
                  description={sample.description}
                  originalImage={sample.original}
                  enhancedImage={sample.enhanced}
                />
              ))
            ) : (
              // Loading placeholders
              Array.from({ length: 4 }).map((_, index) => (
                <div key={index} className="bg-gray-100 rounded-xl h-64 animate-pulse"></div>
              ))
            )}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Photos?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied users who have enhanced over 10 million photos with our AI technology.
          </p>
          <Button variant="secondary" size="lg" className="text-lg bg-white text-primary hover:bg-gray-100 px-8 shadow-lg">
            Start Enhancing for Free
          </Button>
          <p className="mt-4 text-sm text-blue-100">No credit card required • 3 free enhancements</p>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Home;
