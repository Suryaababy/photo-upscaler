import { CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ComparisonSlider from './ComparisonSlider';

interface ResultViewProps {
  originalImageUrl: string;
  enhancedImageUrl: string;
  onDownload: () => void;
  onReset: () => void;
}

const ResultView = ({
  originalImageUrl,
  enhancedImageUrl,
  onDownload,
  onReset
}: ResultViewProps) => {
  const handleDownload = () => {
    // Create a temporary anchor element to trigger the download
    const a = document.createElement('a');
    a.href = enhancedImageUrl;
    a.download = 'pixelperfect-enhanced.jpg'; // Default filename
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    onDownload();
  };
  
  return (
    <div>
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
          <CheckCircle2 className="h-8 w-8 text-accent" />
        </div>
        <h3 className="text-xl font-semibold mb-2">Enhancement Complete!</h3>
        <p className="text-gray-600 mb-6">
          Your photo has been successfully enhanced. Compare the results below.
        </p>
      </div>
      
      <div className="mb-6">
        <ComparisonSlider
          beforeImage={originalImageUrl}
          afterImage={enhancedImageUrl}
          height="h-96"
        />
      </div>
      
      <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
        <Button onClick={handleDownload}>
          Download Enhanced Image
        </Button>
        <Button variant="outline" onClick={onReset}>
          Enhance Another Photo
        </Button>
      </div>
    </div>
  );
};

export default ResultView;
