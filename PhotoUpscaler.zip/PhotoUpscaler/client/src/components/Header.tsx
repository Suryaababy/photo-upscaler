import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, Download } from "lucide-react";
import { useState } from "react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const handleDownloadCode = () => {
    // Redirect to the download endpoint
    window.location.href = '/api/download-code';
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-2xl font-bold font-heading mr-1">Pixel</span>
              <span className="text-secondary text-2xl font-bold font-heading">Perfect</span>
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-primary font-medium transition">Home</Link>
            <a href="#how-it-works" className="text-gray-700 hover:text-primary font-medium transition">How It Works</a>
            <a href="#examples" className="text-gray-700 hover:text-primary font-medium transition">Examples</a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <div className="md:flex hidden space-x-2">
              <Button 
                variant="secondary" 
                onClick={handleDownloadCode}
                className="bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Code
              </Button>
              <Button variant="ghost">Sign In</Button>
            </div>
            <Button>Get Started</Button>
            
            {/* Mobile menu button */}
            <button 
              className="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-primary hover:bg-gray-100"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-700 hover:text-primary font-medium transition">Home</Link>
              <a href="#how-it-works" className="text-gray-700 hover:text-primary font-medium transition">How It Works</a>
              <a href="#examples" className="text-gray-700 hover:text-primary font-medium transition">Examples</a>
              <Button variant="ghost" className="justify-start">Sign In</Button>
              <Button 
                variant="secondary" 
                className="justify-start bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600" 
                onClick={handleDownloadCode}
              >
                <Download className="h-4 w-4 mr-2" />
                Download Code
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
