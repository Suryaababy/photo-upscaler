import { useState, useEffect } from 'react';
import { Beaker } from 'lucide-react';
import { Progress } from "@/components/ui/progress";

interface ProcessingViewProps {
  imageId: number;
  onProcessingComplete: (enhancedPath: string) => void;
  onProcessingError: (message: string) => void;
}

const ProcessingView = ({
  imageId,
  onProcessingComplete,
  onProcessingError
}: ProcessingViewProps) => {
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    let interval: NodeJS.Timeout;
    let isMounted = true;
    
    // We'll use a polling system to check the status of the image processing
    async function checkStatus() {
      try {
        const response = await fetch(`/api/images/${imageId}`);
        
        if (!response.ok) {
          throw new Error('Failed to get image status');
        }
        
        const data = await response.json();
        
        if (data.status === 'completed' && data.enhancedPath) {
          clearInterval(interval);
          if (isMounted) {
            setProgress(100);
            // Give a little buffer time after reaching 100% before moving to the next screen
            setTimeout(() => {
              onProcessingComplete(data.enhancedPath);
            }, 500);
          }
        } else if (data.status === 'error') {
          clearInterval(interval);
          if (isMounted) {
            onProcessingError('An error occurred while processing the image');
          }
        }
      } catch (error) {
        console.error('Error checking status:', error);
        // Don't clear the interval, we'll keep trying
      }
    }
    
    // Poll the status every 1 second
    interval = setInterval(checkStatus, 1000);
    
    // Simulate progress for visual feedback
    const progressInterval = setInterval(() => {
      if (isMounted) {
        setProgress(prev => {
          // Max out at 90% until we get confirmation of completion
          const nextProgress = prev + (1 + Math.random() * 2);
          return Math.min(nextProgress, 90);
        });
      }
    }, 200);
    
    return () => {
      isMounted = false;
      clearInterval(interval);
      clearInterval(progressInterval);
    };
  }, [imageId, onProcessingComplete, onProcessingError]);
  
  return (
    <div className="text-center mb-6">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
        <Beaker className="h-8 w-8 text-primary animate-pulse" />
      </div>
      <h3 className="text-xl font-semibold mb-2">Enhancing Your Photo</h3>
      <p className="text-gray-600 mb-6">Our AI is working its magic. This will only take a few seconds.</p>
      
      <div className="w-full max-w-md mx-auto">
        <Progress value={progress} className="h-2.5 mb-2" />
      </div>
      <p className="text-sm text-gray-500">{Math.round(progress)}% Complete</p>
    </div>
  );
};

export default ProcessingView;
