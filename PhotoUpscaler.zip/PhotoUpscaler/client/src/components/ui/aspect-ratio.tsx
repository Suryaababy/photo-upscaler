import { AspectRatio as AspectRatioPrimitive } from "@radix-ui/react-aspect-ratio";

const AspectRatio = AspectRatioPrimitive;

export { AspectRatio };
