import { useState, useEffect, useRef } from 'react';
import { ChevronRight, ChevronLeft, MoveHorizontal } from 'lucide-react';

interface ComparisonSliderProps {
  beforeImage: string;
  afterImage: string;
  height?: string;
  beforeLabel?: string;
  afterLabel?: string;
}

const ComparisonSlider = ({
  beforeImage,
  afterImage,
  height = "h-96",
  beforeLabel = "Original",
  afterLabel = "Enhanced"
}: ComparisonSliderProps) => {
  const [position, setPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);

  const updatePosition = (clientX: number) => {
    if (!sliderRef.current) return;
    
    const { left, width } = sliderRef.current.getBoundingClientRect();
    const newPosition = ((clientX - left) / width) * 100;
    setPosition(Math.min(Math.max(newPosition, 0), 100));
  };

  const handleMouseDown = () => {
    setIsDragging(true);
  };

  const handleTouchStart = () => {
    setIsDragging(true);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        updatePosition(e.clientX);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isDragging && e.touches[0]) {
        updatePosition(e.touches[0].clientX);
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('touchend', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchend', handleMouseUp);
    };
  }, [isDragging]);

  return (
    <div className="rounded-xl overflow-hidden shadow-2xl">
      <div 
        ref={sliderRef}
        className={`comparison-slider relative ${height}`} 
        style={{ 
          "--position": `${position}%` 
        } as React.CSSProperties}
      >
        <div 
          className="before" 
          style={{ backgroundImage: `url('${beforeImage}')` }}
        ></div>
        <div 
          className="after" 
          style={{ backgroundImage: `url('${afterImage}')` }}
        ></div>
        <div className="slider">
          <div 
            className="slider-button"
            onMouseDown={handleMouseDown}
            onTouchStart={handleTouchStart}
          >
            <MoveHorizontal className="h-5 w-5 text-primary" />
          </div>
        </div>
      </div>
      <div className="bg-white p-4 flex justify-between">
        <div className="flex items-center">
          <ChevronLeft className="h-4 w-4 text-gray-500 mr-1" />
          <span className="font-medium">{beforeLabel}</span>
        </div>
        <div className="flex items-center">
          <span className="font-medium">{afterLabel}</span>
          <ChevronRight className="h-4 w-4 text-gray-500 ml-1" />
        </div>
      </div>
    </div>
  );
};

export default ComparisonSlider;
