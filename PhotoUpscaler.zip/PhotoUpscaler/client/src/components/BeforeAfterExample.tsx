import { AspectRatio } from "@/components/ui/aspect-ratio";

interface BeforeAfterExampleProps {
  title: string;
  description: string;
  originalImage: string;
  enhancedImage: string;
}

const BeforeAfterExample = ({
  title,
  description,
  originalImage,
  enhancedImage
}: BeforeAfterExampleProps) => {
  return (
    <div className="bg-gray-50 rounded-xl overflow-hidden shadow-md transition hover:shadow-lg">
      <div className="grid grid-cols-2">
        <div className="relative">
          <AspectRatio ratio={4/3}>
            <img 
              src={originalImage} 
              alt={`Original ${title}`} 
              className="object-cover w-full h-full"
            />
          </AspectRatio>
          <div className="absolute bottom-2 left-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">Original</div>
        </div>
        <div className="relative">
          <AspectRatio ratio={4/3}>
            <img 
              src={enhancedImage} 
              alt={`Enhanced ${title}`} 
              className="object-cover w-full h-full" 
              style={{ filter: "brightness(1.1) contrast(1.05) saturate(1.1)" }}
            />
          </AspectRatio>
          <div className="absolute bottom-2 left-2 bg-primary bg-opacity-70 text-white text-xs px-2 py-1 rounded">Enhanced</div>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-medium">{title}</h3>
        <p className="text-sm text-gray-500">{description}</p>
      </div>
    </div>
  );
};

export default BeforeAfterExample;
