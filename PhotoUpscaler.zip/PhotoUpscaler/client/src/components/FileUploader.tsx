import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { ImageIcon, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ALLOWED_FILE_TYPES, MAX_FILE_SIZE } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface FileUploaderProps {
  onFileUploadStart: () => void;
  onFileUploadSuccess: (data: { id: number; originalPath: string }) => void;
  onFileUploadError: (error: string) => void;
}

const FileUploader = ({ 
  onFileUploadStart, 
  onFileUploadSuccess, 
  onFileUploadError 
}: FileUploaderProps) => {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;
    
    const file = acceptedFiles[0];
    
    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      toast({
        title: "File too large",
        description: `Maximum file size is ${MAX_FILE_SIZE / (1024 * 1024)}MB`,
        variant: "destructive"
      });
      return;
    }
    
    // Validate file type
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: `Only ${ALLOWED_FILE_TYPES.join(', ')} files are allowed`,
        variant: "destructive"
      });
      return;
    }
    
    setIsUploading(true);
    onFileUploadStart();
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await apiRequest('POST', '/api/upload', undefined, {
        body: formData,
        headers: {
          // Don't set Content-Type here, let browser set it with boundary for FormData
        }
      });
      
      const data = await response.json();
      onFileUploadSuccess(data);
    } catch (error) {
      console.error('Upload error:', error);
      onFileUploadError(error instanceof Error ? error.message : 'Error uploading file');
    } finally {
      setIsUploading(false);
    }
  }, [onFileUploadStart, onFileUploadSuccess, onFileUploadError, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': [],
      'image/png': [],
      'image/webp': []
    },
    maxFiles: 1,
    disabled: isUploading
  });

  return (
    <div 
      {...getRootProps()} 
      className={`border-2 border-dashed rounded-lg p-8 text-center transition cursor-pointer ${
        isDragActive 
          ? 'border-primary bg-primary/5' 
          : 'border-gray-300 hover:border-primary'
      }`}
    >
      <input {...getInputProps()} />
      <ImageIcon className="mx-auto h-14 w-14 text-gray-400 mb-4" />
      <h3 className="text-xl font-medium mb-2">
        {isDragActive ? "Drop Your Photo Here" : "Drag & Drop Your Photo Here"}
      </h3>
      <p className="text-gray-500 mb-4">or</p>
      <Button disabled={isUploading}>
        <Upload className="h-4 w-4 mr-2" />
        Browse Files
      </Button>
      <p className="mt-4 text-sm text-gray-500">
        Supports JPG, PNG, WEBP • Max 10MB
      </p>
    </div>
  );
};

export default FileUploader;
